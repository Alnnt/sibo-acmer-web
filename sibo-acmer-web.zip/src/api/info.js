import request from "@/util/request.js";

export function getCdkeyStatue({ cdkey }) {
  return request.get('/info/cdkey', {
    params: {
      cdkey
    }
  });
}

export async function listSchool(schoolName) {
  // return request.get('/info/list_school', {
  //   params: {
  //     schoolName
  //   }
  // });
  console.log(schoolName);
  return [
    {
      "id": "57ddd07c62fb43f9ac864632a8e652b4",
      "schoolName": "山东女子学院"
    },
    {
      "id": "88303ab2b3ee4480b68642b257e9592e",
      "schoolName": "山东外事职业大学"
    },
    {
      "id": "c2e8a6620de54571883d925f93d36dc1",
      "schoolName": "山东体育学院"
    },
    {
      "id": "d166f0a152a84f509829020dac100f85",
      "schoolName": "山东管理学院"
    },
    {
      "id": "d84b470c120e45ed957e99a93d7a5558",
      "schoolName": "山东第一医科大学"
    },
    {
      "id": "201698653ebd4f4b8f6e321c3dca2ebe",
      "schoolName": "山东工商学院"
    },
    {
      "id": "3a1d61458ed341fd8693afff83863cdd",
      "schoolName": "山东建筑大学"
    },
    {
      "id": "80514d08757341769bf4fd9c1409bb68",
      "schoolName": "山东艺术学院"
    },
    {
      "id": "dcd3bdf87ec349259d08f165243426b8",
      "schoolName": "山东农业大学"
    },
    {
      "id": "9521b2f9252b488ca06717b104ac96ed",
      "schoolName": "山东传媒职业学院"
    }
  ];
}
