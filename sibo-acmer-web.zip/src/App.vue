<script setup>
import { RouterView } from 'vue-router'

</script>

<template>
  <RouterView />
</template>

<style>
body {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background: url("https://api.r10086.com/樱道随机图片api接口.php?图片系列=动漫综合2") no-repeat center;
  background-size: cover;
}
</style>
